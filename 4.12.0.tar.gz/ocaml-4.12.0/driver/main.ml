let () =
  exit (Maindriver.main Sys.argv Format.err_formatter)
